package com.example.books;

public class Books {

    private int iban;
    private String name;
    private String author;

    public Books(String name, String author, int iban) {
        this.name = name;
        this.author = author;
        this.iban = iban;
    }

    public String getAuthor() { return author; }

    public void setAuthor(String author) { this.author = author; }

    public int getIban() {
        return iban;
    }

    public void setIban(int iban) {
        this.iban = iban;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
