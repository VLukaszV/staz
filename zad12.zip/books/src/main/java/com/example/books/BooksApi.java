package com.example.books;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;


@RestController
@RequestMapping("api/books")
public class BooksApi {

    private List<Books> booksList;

    @Autowired
    public BooksApi(){
        this.booksList = new ArrayList<>();
    }


    @GetMapping("/{id}")
    public Books getBooks(@PathVariable int id){
        return booksList.stream()
                .filter(books -> books.getIban()==id).findFirst().get();
    }

    @GetMapping
    public List<Books> getBooksList(){
        return booksList;
    }

}
